"""SQLite persistence for inference contracts."""

from .sqlite_writer import SqliteWriter

__all__ = ["SqliteWriter"]
