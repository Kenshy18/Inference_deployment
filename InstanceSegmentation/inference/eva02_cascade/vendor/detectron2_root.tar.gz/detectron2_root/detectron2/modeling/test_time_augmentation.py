# Copyright (c) Facebook, Inc. and its affiliates.
import copy
import glob
import os.path
import warnings

from pycocotools.coco import COCO
try:
    from mmcv.ops import soft_nms as _soft_nms  # type: ignore
except Exception:  # pragma: no cover - optional dependency for TTA soft-NMS
    _soft_nms = None


def soft_nms(*args, **kwargs):
    if _soft_nms is None:
        raise ImportError(
            "mmcv is required for soft_nms. Install mmcv-full or disable soft-NMS in TTA."
        )
    return _soft_nms(*args, **kwargs)

import numpy as np
from contextlib import contextmanager
from itertools import count
from typing import List
import torch
from fvcore.transforms import HFlipTransform, NoOpTransform
from torch import nn
from torch.nn.parallel import DistributedDataParallel

from detectron2.config import configurable
from detectron2.data.detection_utils import read_image
from detectron2.data.transforms import (
    RandomFlip,
    ResizeShortestEdge,
    ResizeTransform,
    apply_augmentations,
)
from detectron2.structures import Boxes, Instances

from .meta_arch import GeneralizedRCNN
from .postprocessing import detector_postprocess
from .roi_heads.fast_rcnn import fast_rcnn_inference_single_image
from detectron2.config import CfgNode
from omegaconf.dictconfig import DictConfig
import detectron2.utils.comm as comm

__all__ = ["DatasetMapperTTA", "GeneralizedRCNNWithTTA"]


class DatasetMapperTTA:
    """
    Implement test-time augmentation for detection data.
    It is a callable which takes a dataset dict from a detection dataset,
    and returns a list of dataset dicts where the images
    are augmented from the input image by the transformations defined in the config.
    This is used for test-time augmentation.
    """

    @configurable
    def __init__(
            self,
            # min_sizes: List[int] = (416, 512, 608, 704, 800, 1280, 1408, 1536, 1664),
            # max_size: List[int] = (1280, 1280, 1280, 1280, 1280, 1280, 1408, 1536, 1664),
            min_sizes: List[int] = None,
            max_size: List[int] = None,
            flip: bool = False,
    ):
        """
        Default args are from d2 Mask RCNN

        Args:
            min_sizes: list of short-edge size to resize the image to
            max_size: maximum height or width of resized images
            flip: whether to apply flipping augmentation
        """
        assert len(min_sizes) == len(max_size)
        self.min_sizes = min_sizes
        self.max_size = max_size
        self.flip = flip

    @classmethod
    def from_config(cls, cfg):
        if isinstance(cfg, CfgNode):
            return {
                "min_sizes": cfg.TEST.AUG.MIN_SIZES,
                "max_size": cfg.TEST.AUG.MAX_SIZE,
                "flip": cfg.TEST.AUG.FLIP,
            }
        elif isinstance(cfg, DictConfig):
            if 'min_sizes' not in cfg.test.aug:
                # cfg.test.aug.min_sizes = (1280, 1920)
                # cfg.test.aug.min_sizes = (
                #     416, 512, 608, 704, 800, 1280,
                #     # 1408,
                #     1536, 1664, 1792, 1920,
                #     2048, 2176, 2304, 2432, 2560,
                # )
                cfg.test.aug.min_sizes = (1280, 1536, 1664, 1792, 1920, 2048)
                # cfg.test.aug.min_sizes = (1024, 1280, 1536)
                warnings.warn("test.aug.min_sizes is not set, using default values!")
            if 'max_size' not in cfg.test.aug:
                # cfg.test.aug.max_size = (1280, 1920)
                # cfg.test.aug.max_size = (
                #     1280, 1280, 1280, 1280, 1280, 1280,
                #     # 1408,
                #     1536, 1664, 1792, 1920,
                #     2048, 2176, 2304, 2432, 2560,
                # )
                cfg.test.aug.max_size = (1280, 1536, 1664, 1792, 1920, 2048)
                # cfg.test.aug.max_size = (1024, 1280, 1536)
                warnings.warn("test.aug.max_size is not set, using default values!")
            if 'flip' not in cfg.test.aug:
                cfg.test.aug.flip = False
                warnings.warn("test.aug.flip is not set, using default values (False)!")
            if isinstance(cfg.test.aug.min_sizes, int):
                cfg.test.aug.min_sizes = [cfg.test.aug.min_sizes]
            if isinstance(cfg.test.aug.max_size, int):
                cfg.test.aug.max_size = [cfg.test.aug.max_size]
            return {
                "min_sizes": cfg.test.aug.min_sizes,
                "max_size": cfg.test.aug.max_size,
                "flip": cfg.test.aug.flip,
            }
        else:
            raise NotImplementedError

    def __call__(self, dataset_dict):
        """
        Args:
            dict: a dict in standard model input format. See tutorials for details.

        Returns:
            list[dict]:
                a list of dicts, which contain augmented version of the input image.
                The total number of dicts is ``len(min_sizes) * (2 if flip else 1)``.
                Each dict has field "transforms" which is a TransformList,
                containing the transforms that are used to generate this image.
        """
        numpy_image = dataset_dict["image"].permute(1, 2, 0).numpy()
        shape = numpy_image.shape
        orig_shape = (dataset_dict["height"], dataset_dict["width"])
        if shape[:2] != orig_shape:
            # It transforms the "original" image in the dataset to the input image
            pre_tfm = ResizeTransform(orig_shape[0], orig_shape[1], shape[0], shape[1])
        else:
            pre_tfm = NoOpTransform()

        # Create all combinations of augmentations to use
        aug_candidates = []  # each element is a list[Augmentation]
        # for min_size in self.min_sizes:
        for min_size, max_size in zip(self.min_sizes, self.max_size):
            resize = ResizeShortestEdge(min_size, max_size)
            aug_candidates.append([resize])  # resize only
            if self.flip:
                flip = RandomFlip(prob=1.0)
                aug_candidates.append([resize, flip])  # resize + flip

        # Apply all the augmentations
        ret = []
        for idx, aug in enumerate(aug_candidates):
            new_image, tfms = apply_augmentations(aug, np.copy(numpy_image))
            torch_image = torch.from_numpy(np.ascontiguousarray(new_image.transpose(2, 0, 1)))

            dic = copy.deepcopy(dataset_dict)
            dic["transforms"] = pre_tfm + tfms
            dic["min_size"] = self.min_sizes[idx]
            dic["max_size"] = self.max_size[idx]
            dic["image"] = torch_image
            ret.append(dic)
        return ret


class GeneralizedRCNNWithTTA(nn.Module):
    """
    A GeneralizedRCNN with test-time augmentation enabled.
    Its :meth:`__call__` method has the same interface as :meth:`GeneralizedRCNN.forward`.
    """

    def __init__(self, cfg, model, tta_mapper=None, batch_size=3):
        """
        Args:
            cfg (CfgNode):
            model (GeneralizedRCNN): a GeneralizedRCNN to apply TTA on.
            tta_mapper (callable): takes a dataset dict and returns a list of
                augmented versions of the dataset dict. Defaults to
                `DatasetMapperTTA(cfg)`.
            batch_size (int): batch the augmented images into this batch size for inference.
        """
        super().__init__()
        if isinstance(model, DistributedDataParallel):
            model = model.module
        assert isinstance(
            model, GeneralizedRCNN
        ), "TTA is only supported on GeneralizedRCNN. Got a model of type {}".format(type(model))
        self.cfg = copy.deepcopy(cfg)
        if isinstance(cfg, CfgNode):
            assert not self.cfg.MODEL.KEYPOINT_ON, "TTA for keypoint is not supported yet"
            assert (
                not self.cfg.MODEL.LOAD_PROPOSALS
            ), "TTA for pre-computed proposals is not supported yet"

        self.model = model

        if tta_mapper is None:
            tta_mapper = DatasetMapperTTA(cfg)
        self.tta_mapper = tta_mapper
        self.batch_size = batch_size
        # self.size2scale = {
        #     416: [256 ** 2, 1e5 ** 2],
        #     512: [160 ** 2, 1e5 ** 2],
        #     608: [128 ** 2, 1e5 ** 2],
        #     704: [96 ** 2, 256 ** 2],
        #     800: [64 ** 2, 128 ** 2],
        #     1280: [48 ** 2, 128 ** 2],
        #     1408: [32 ** 2, 64 ** 2],
        #     1536: [16 ** 2, 64 ** 2],
        #     1664: [24 ** 2, 48 ** 2],
        #     1792: [8 ** 2, 32 ** 2],
        #     1920: [16 ** 2, 32 ** 2],
        #     2048: [8 ** 2, 16 ** 2],
        #     2176: [0 ** 2, 24 ** 2],
        #     2304: [0 ** 2, 24 ** 2],
        #     2432: [0 ** 2, 16 ** 2],
        #     2560: [0 ** 2, 16 ** 2],
        # }
        # self.size2scale = {
        #     416: [256 ** 2, 1e5 ** 2],
        #     512: [160 ** 2, 1e5 ** 2],
        #     608: [128 ** 2, 1e5 ** 2],
        #     704: [96 ** 2, 256 ** 2],
        #     800: [64 ** 2, 128 ** 2],
        #     1280: [32 ** 2, 1e5 ** 2],
        #     # 1408: [32 ** 2, 64 ** 2],
        #     1536: [16 ** 2, 1e5 ** 2],
        #     1664: [0 ** 2, 1e5 ** 2],
        #     1792: [0 ** 2, 16 ** 2],
        #     1920: [0 ** 2, 24 ** 2],
        #     2048: [0 ** 2, 16 ** 2],
        #     2176: [0 ** 2, 24 ** 2],
        #     2304: [0 ** 2, 24 ** 2],
        #     2432: [0 ** 2, 16 ** 2],
        #     2560: [0 ** 2, 16 ** 2],
        # }
        self.size2scale = {
            1280: [32 ** 2, 1e5 ** 2],
            1536: [16 ** 2, 1e5 ** 2],
            1664: [0 ** 2, 1e5 ** 2],
            1792: [0 ** 2, 16 ** 2],
            1920: [0 ** 2, 24 ** 2],
            2048: [0 ** 2, 16 ** 2],
        }

    @contextmanager
    def _turn_off_roi_heads(self, attrs):
        """
        Open a context where some heads in `model.roi_heads` are temporarily turned off.
        Args:
            attr (list[str]): the attribute in `model.roi_heads` which can be used
                to turn off a specific head, e.g., "mask_on", "keypoint_on".
        """
        roi_heads = self.model.roi_heads
        old = {}
        for attr in attrs:
            try:
                old[attr] = getattr(roi_heads, attr)
            except AttributeError:
                # The head may not be implemented in certain ROIHeads
                pass

        if len(old.keys()) == 0:
            yield
        else:
            for attr in old.keys():
                setattr(roi_heads, attr, False)
            yield
            for attr in old.keys():
                setattr(roi_heads, attr, old[attr])

    def _batch_inference(self, batched_inputs, detected_instances=None, keep_all_before_merge=False):
        """
        Execute inference on a list of inputs,
        using batch size = self.batch_size, instead of the length of the list.

        Inputs & outputs have the same format as :meth:`GeneralizedRCNN.inference`
        """
        if detected_instances is None:
            detected_instances = [None] * len(batched_inputs)

        outputs = []
        inputs, instances = [], []
        for idx, input, instance in zip(count(), batched_inputs, detected_instances):
            inputs.append(input)
            instances.append(instance)
            if len(inputs) == self.batch_size or idx == len(batched_inputs) - 1:
                # TODO: note nms/soft-nms is applied in rcnn.inference -> CascadeROIHeads.forward -> ._forward_box
                outputs.extend(
                    self.model.inference(
                        inputs,
                        instances if instances[0] is not None else None,
                        do_postprocess=False,
                        keep_all_before_merge=keep_all_before_merge,
                    )
                )
                inputs, instances = [], []
        return outputs

    def __call__(self, batched_inputs):
        """
        Same input/output format as :meth:`GeneralizedRCNN.forward`
        """

        def _maybe_read_image(dataset_dict):
            ret = copy.copy(dataset_dict)
            if "image" not in ret:
                image = read_image(ret.pop("file_name"), self.model.input_format)
                image = torch.from_numpy(np.ascontiguousarray(image.transpose(2, 0, 1)))  # CHW
                ret["image"] = image
            if "height" not in ret and "width" not in ret:
                ret["height"] = image.shape[1]
                ret["width"] = image.shape[2]
            return ret

        return [self._inference_one_image(_maybe_read_image(x)) for x in batched_inputs]

    def _inference_one_image(self, input):
        """
        Args:
            input (dict): one dataset dict with "image" field being a CHW tensor

        Returns:
            dict: one output dict
        """
        orig_shape = (input["height"], input["width"])
        augmented_inputs, tfms, min_sizes, max_sizes = self._get_augmented_inputs(input)
        # Detect boxes from all augmented versions
        with self._turn_off_roi_heads(["mask_on", "keypoint_on"]):
            # temporarily disable roi heads
            all_boxes, all_scores, all_classes = self._get_augmented_boxes(augmented_inputs, tfms, min_sizes, max_sizes, input)
        # merge all detected boxes to obtain final predictions for boxes
        merged_instances = self._merge_detections(all_boxes, all_scores, all_classes, orig_shape)

        if isinstance(self.cfg, CfgNode):
            MASK_ON = self.cfg.MODEL.MASK_ON
        elif isinstance(self.cfg, DictConfig):
            MASK_ON = False if self.cfg.model.roi_heads.mask_head is None else True
        else:
            raise NotImplementedError
        MASK_ON = True if 'maskness_thresh' in self.cfg.model.roi_heads else False

        # todo: apply maskness on tta merge
        if MASK_ON:
            # todo: select a single scale for crop
            target_scale = 1536
            target_aug_idx = 1
            for aug_idx, aug_input in enumerate(augmented_inputs):
                _, height, width = aug_input['image'].shape
                max_size = max(height, width)
                if max_size == target_scale:
                    target_aug_idx_check = aug_idx
                    break
            assert target_aug_idx_check == target_aug_idx, target_aug_idx_check
            augmented_inputs = [augmented_inputs[target_aug_idx]]
            tfms = [tfms[target_aug_idx]]

            # Use the detected boxes to obtain masks
            augmented_instances = self._rescale_detected_boxes(
                augmented_inputs, merged_instances, tfms
            )
            # run forward on the detected boxes
            outputs = self._batch_inference(augmented_inputs, augmented_instances)
            # Delete now useless variables to avoid being out of memory
            del augmented_inputs, augmented_instances
            # average the predictions
            merged_instances.pred_masks = self._reduce_pred_masks(outputs, tfms)
            merged_instances = detector_postprocess(merged_instances, *orig_shape)
            return {"instances": merged_instances}
        else:
            return {"instances": merged_instances}

    def _get_augmented_inputs(self, input):
        augmented_inputs = self.tta_mapper(input)
        tfms = [x.pop("transforms") for x in augmented_inputs]
        min_sizes = [x.pop("min_size") for x in augmented_inputs]
        max_sizes = [x.pop("max_size") for x in augmented_inputs]
        return augmented_inputs, tfms, min_sizes, max_sizes

    def _get_augmented_boxes(self, augmented_inputs, tfms, min_sizes, max_sizes, input):
        # 1: forward with all augmented images
        keep_all_before_merge = self.cfg.test.aug.keep_all_before_merge if 'keep_all_before_merge' in self.cfg.test.aug else False

        # save & load before scale selection below
        if 'pred_dir' in self.cfg.test.aug:
            assert 'save_dir' not in self.cfg.test.aug
            outputs = []
            # make sure outputs and tfms, min_sizes are in same order
            for aug_input, min_s, max_s in zip(augmented_inputs, min_sizes, max_sizes):
                file_name = os.path.join(
                    self.cfg.test.aug.pred_dir,
                    os.path.basename(aug_input['file_name']).replace('.jpg', '_{}x{}.pth'.format(min_s, max_s))
                )
                result = torch.load(file_name).to("cuda:{}".format(comm.get_local_rank()))
                # post filtering if needed
                use_soft_nms_before_merge = False
                if use_soft_nms_before_merge:
                    # Apply NMS for each class independently
                    boxes = result.pred_boxes
                    filter_inds = result.pred_classes
                    scores = result.scores
                    try:
                        max_coordinate = boxes.max()
                    except:
                        print(boxes.shape)  # empty
                        warnings.warn("setting max_coordinate to 0")
                        max_coordinate = 0
                    idxs = filter_inds
                    offsets = idxs.to(boxes) * (max_coordinate + torch.tensor(1).to(boxes))
                    boxes_for_nms = boxes + offsets[:, None]
                    dets, keep = soft_nms(boxes=boxes_for_nms, scores=scores, iou_threshold=0.6,
                                          sigma=0.5, min_score=1e-3, method="linear")
                    boxes = boxes[keep]
                    scores = dets[:, -1]  # scores are updated in soft-nms

                    result_nms = Instances(result.image_size)
                    result_nms.pred_boxes = boxes
                    result_nms.scores = scores
                    filter_inds = filter_inds[keep]
                    result_nms.pred_classes = filter_inds
                    result = result_nms
                outputs.append(result)
            # for idx in range(len(outputs)):
            #     outputs[idx].to()
        else:
            outputs = self._batch_inference(augmented_inputs, keep_all_before_merge=keep_all_before_merge)

        if 'save_dir' in self.cfg.test.aug:
            if not os.path.exists(self.cfg.test.aug.save_dir):
                os.makedirs(self.cfg.test.aug.save_dir)
            assert len(augmented_inputs) == len(outputs) == 1, "save one scale at a time"
            assert input['file_name'] == augmented_inputs[0]['file_name']
            file_name = os.path.join(
                self.cfg.test.aug.save_dir,
                os.path.basename(input['file_name']).replace
                ('.jpg', '_{}x{}.pth'.format(self.cfg.test.aug.min_sizes, self.cfg.test.aug.max_size))
            )
            assert not os.path.exists(file_name), file_name
            torch.save(outputs[0], file_name)

        # 2: union the results
        all_boxes = []
        all_scores = []
        all_classes = []
        for output, tfm, min_size in zip(outputs, tfms, min_sizes):
            # Need to inverse the transforms on boxes, to obtain results on original image
            pred_boxes = output.pred_boxes.tensor
            original_pred_boxes = tfm.inverse().apply_box(pred_boxes.cpu().numpy())
            original_pred_boxes = torch.from_numpy(original_pred_boxes).to(pred_boxes.device)

            # TODO: select scale on original boxes!
            if 'select_scales' in self.cfg.test.aug and self.cfg.test.aug.select_scales:
                assert len(min_sizes) == len(self.size2scale)
                range_to_keep = self.size2scale[min_size]
                # area = output.pred_boxes.area()
                area = (original_pred_boxes[:, 2] - original_pred_boxes[:, 0]) * \
                       (original_pred_boxes[:, 3] - original_pred_boxes[:, 1])
                keep = (area >= range_to_keep[0]) * (area <= range_to_keep[1])
                original_pred_boxes = original_pred_boxes[keep]
                for k, v in output._fields.items():
                    output._fields[k] = v[keep]

            assert len(original_pred_boxes) == len(output.scores) == len(output.pred_classes)
            all_boxes.append(original_pred_boxes)
            all_scores.extend(output.scores)
            all_classes.extend(output.pred_classes)
        all_boxes = torch.cat(all_boxes, dim=0)
        return all_boxes, all_scores, all_classes

    def _merge_detections(self, all_boxes, all_scores, all_classes, shape_hw):
        if isinstance(self.cfg, CfgNode):
            num_classes = self.cfg.MODEL.ROI_HEADS.NUM_CLASSES
            test_nms_thresh = self.cfg.MODEL.ROI_HEADS.NMS_THRESH_TEST
            test_topk_per_image = self.cfg.TEST.DETECTIONS_PER_IMAGE
        elif isinstance(self.cfg, DictConfig):
            try:
                num_classes = self.model.roi_heads.box_predictor[-1].num_classes
                test_nms_thresh = self.model.roi_heads.box_predictor[-1].test_nms_thresh
                test_topk_per_image = self.model.roi_heads.box_predictor[-1].test_topk_per_image
            except:
                num_classes = self.model.roi_heads.box_predictor.num_classes
                test_nms_thresh = self.model.roi_heads.box_predictor.test_nms_thresh
                test_topk_per_image = self.model.roi_heads.box_predictor.test_topk_per_image
        else:
            raise NotImplementedError

        # select from the union of all results
        num_boxes = len(all_boxes)

        # +1 because fast_rcnn_inference expects background scores as well
        all_scores_2d = torch.zeros(num_boxes, num_classes + 1, device=all_boxes.device)
        for idx, cls, score in zip(count(), all_classes, all_scores):
            all_scores_2d[idx, cls] = score

        # TODO: soft-nms can also be called here, avoid repeated nms on single input with keep_all
        merged_instances, _ = fast_rcnn_inference_single_image(
            all_boxes,
            all_scores_2d,
            shape_hw,
            1e-8,
            test_nms_thresh,
            test_topk_per_image,
            use_soft_nms=self.cfg.test.aug.use_soft_nms if 'use_soft_nms' in self.cfg.test.aug else False,
            method=self.cfg.test.aug.method if 'method' in self.cfg.test.aug else 'linear',
            iou_threshold=self.cfg.test.aug.iou_threshold if 'iou_threshold' in self.cfg.test.aug else 0.3,
            sigma=self.cfg.test.aug.sigma if 'sigma' in self.cfg.test.aug else 0.5,
            class_wise=self.cfg.test.aug.class_wise if 'class_wise' in self.cfg.test.aug else False,
            override_score_thresh=self.cfg.test.aug.override_score_thresh if 'override_score_thresh' in self.cfg.test.aug else None,
            keep_all=self.cfg.test.aug.keep_all_when_merge if 'keep_all_when_merge' in self.cfg.test.aug else False,
        )

        return merged_instances

    def _rescale_detected_boxes(self, augmented_inputs, merged_instances, tfms):
        augmented_instances = []
        for input, tfm in zip(augmented_inputs, tfms):
            # Transform the target box to the augmented image's coordinate space
            pred_boxes = merged_instances.pred_boxes.tensor.cpu().numpy()
            pred_boxes = torch.from_numpy(tfm.apply_box(pred_boxes))

            aug_instances = Instances(
                image_size=input["image"].shape[1:3],
                pred_boxes=Boxes(pred_boxes),
                pred_classes=merged_instances.pred_classes,
                scores=merged_instances.scores,
            )
            augmented_instances.append(aug_instances)
        return augmented_instances

    def _reduce_pred_masks(self, outputs, tfms):
        # Should apply inverse transforms on masks.
        # We assume only resize & flip are used. pred_masks is a scale-invariant
        # representation, so we handle flip specially
        for output, tfm in zip(outputs, tfms):
            if any(isinstance(t, HFlipTransform) for t in tfm.transforms):
                output.pred_masks = output.pred_masks.flip(dims=[3])
        all_pred_masks = torch.stack([o.pred_masks for o in outputs], dim=0)
        avg_pred_masks = torch.mean(all_pred_masks, dim=0)
        return avg_pred_masks
