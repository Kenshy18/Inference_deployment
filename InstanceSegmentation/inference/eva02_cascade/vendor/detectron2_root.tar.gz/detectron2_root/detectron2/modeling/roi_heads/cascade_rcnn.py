# Copyright (c) Facebook, Inc. and its affiliates.
import os
from typing import List
import torch
from torch import nn
from torch.autograd.function import Function

from detectron2.config import configurable
from detectron2.layers import ShapeSpec
from detectron2.structures import Boxes, Instances, pairwise_iou
from detectron2.utils.events import get_event_storage

from ..box_regression import Box2BoxTransform
from ..matcher import Matcher
from ..poolers import ROIPooler
from .box_head import build_box_head
from .fast_rcnn import FastRCNNOutputLayers, fast_rcnn_inference
from .roi_heads import ROI_HEADS_REGISTRY, StandardROIHeads


class _ScaleGradient(Function):
    @staticmethod
    def forward(ctx, input, scale):
        ctx.scale = scale
        return input

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output * ctx.scale, None


@ROI_HEADS_REGISTRY.register()
class CascadeROIHeads(StandardROIHeads):
    """
    The ROI heads that implement :paper:`Cascade R-CNN`.
    """

    @configurable
    def __init__(
        self,
        *,
        box_in_features: List[str],
        box_pooler: ROIPooler,
        box_heads: List[nn.Module],
        box_predictors: List[nn.Module],
        proposal_matchers: List[Matcher],
        use_soft_nms: bool = False,
        method: str = 'linear',
        iou_threshold: float = 0.3,
        sigma: float = 0.5,
        class_wise: bool = False,
        override_score_thresh: float = None,
        maskness_thresh: float = None,
        **kwargs,
    ):
        """
        NOTE: this interface is experimental.

        Args:
            box_pooler (ROIPooler): pooler that extracts region features from given boxes
            box_heads (list[nn.Module]): box head for each cascade stage
            box_predictors (list[nn.Module]): box predictor for each cascade stage
            proposal_matchers (list[Matcher]): matcher with different IoU thresholds to
                match boxes with ground truth for each stage. The first matcher matches
                RPN proposals with ground truth, the other matchers use boxes predicted
                by the previous stage as proposals and match them with ground truth.
        """
        assert "proposal_matcher" not in kwargs, (
            "CascadeROIHeads takes 'proposal_matchers=' for each stage instead "
            "of one 'proposal_matcher='."
        )
        # The first matcher matches RPN proposals with ground truth, done in the base class
        kwargs["proposal_matcher"] = proposal_matchers[0]
        num_stages = self.num_cascade_stages = len(box_heads)
        box_heads = nn.ModuleList(box_heads)
        box_predictors = nn.ModuleList(box_predictors)
        assert len(box_predictors) == num_stages, f"{len(box_predictors)} != {num_stages}!"
        assert len(proposal_matchers) == num_stages, f"{len(proposal_matchers)} != {num_stages}!"
        super().__init__(
            box_in_features=box_in_features,
            box_pooler=box_pooler,
            box_head=box_heads,
            box_predictor=box_predictors,
            **kwargs,
        )
        self.proposal_matchers = proposal_matchers
        self.use_soft_nms = use_soft_nms
        self.method = method
        self.iou_threshold = iou_threshold
        self.sigma = sigma
        self.class_wise = class_wise
        self.override_score_thresh = override_score_thresh
        self.maskness_thresh = maskness_thresh
        self.return_box_features = False
        self.return_box_pooler_features = False
        self.return_box_pooler_features_expanded = False
        self.box_pooler_expanded_scale = 2.0
        self.return_mask_pooler_features = False
        self.fixed_num_proposals = 0

    @classmethod
    def from_config(cls, cfg, input_shape):
        ret = super().from_config(cfg, input_shape)
        ret.pop("proposal_matcher")
        return ret

    @classmethod
    def _init_box_head(cls, cfg, input_shape):
        # fmt: off
        in_features              = cfg.MODEL.ROI_HEADS.IN_FEATURES
        pooler_resolution        = cfg.MODEL.ROI_BOX_HEAD.POOLER_RESOLUTION
        pooler_scales            = tuple(1.0 / input_shape[k].stride for k in in_features)
        sampling_ratio           = cfg.MODEL.ROI_BOX_HEAD.POOLER_SAMPLING_RATIO
        pooler_type              = cfg.MODEL.ROI_BOX_HEAD.POOLER_TYPE
        cascade_bbox_reg_weights = cfg.MODEL.ROI_BOX_CASCADE_HEAD.BBOX_REG_WEIGHTS
        cascade_ious             = cfg.MODEL.ROI_BOX_CASCADE_HEAD.IOUS
        assert len(cascade_bbox_reg_weights) == len(cascade_ious)
        assert cfg.MODEL.ROI_BOX_HEAD.CLS_AGNOSTIC_BBOX_REG,  \
            "CascadeROIHeads only support class-agnostic regression now!"
        assert cascade_ious[0] == cfg.MODEL.ROI_HEADS.IOU_THRESHOLDS[0]
        # fmt: on

        in_channels = [input_shape[f].channels for f in in_features]
        # Check all channel counts are equal
        assert len(set(in_channels)) == 1, in_channels
        in_channels = in_channels[0]

        box_pooler = ROIPooler(
            output_size=pooler_resolution,
            scales=pooler_scales,
            sampling_ratio=sampling_ratio,
            pooler_type=pooler_type,
        )
        pooled_shape = ShapeSpec(
            channels=in_channels, width=pooler_resolution, height=pooler_resolution
        )

        box_heads, box_predictors, proposal_matchers = [], [], []
        for match_iou, bbox_reg_weights in zip(cascade_ious, cascade_bbox_reg_weights):
            box_head = build_box_head(cfg, pooled_shape)
            box_heads.append(box_head)
            box_predictors.append(
                FastRCNNOutputLayers(
                    cfg,
                    box_head.output_shape,
                    box2box_transform=Box2BoxTransform(weights=bbox_reg_weights),
                )
            )
            proposal_matchers.append(Matcher([match_iou], [0, 1], allow_low_quality_matches=False))
        return {
            "box_in_features": in_features,
            "box_pooler": box_pooler,
            "box_heads": box_heads,
            "box_predictors": box_predictors,
            "proposal_matchers": proposal_matchers,
        }

    def forward(self, images, features, proposals, targets=None, keep_all_before_merge=False):
        del images
        if self.training:
            proposals = self.label_and_sample_proposals(proposals, targets)

        if self.training:
            # Need targets to box head
            losses = self._forward_box(features, proposals, targets)
            losses.update(self._forward_mask(features, proposals))
            losses.update(self._forward_keypoint(features, proposals))
            return proposals, losses
        else:
            pred_instances = self._forward_box(features, proposals, keep_all_before_merge=keep_all_before_merge)
            pred_instances = self.forward_with_given_boxes(features, pred_instances)
            # optionally update score using maskness
            if self.maskness_thresh is not None:
                for pred_inst in pred_instances:
                    # pred_inst._fields.keys():  dict_keys(['pred_boxes', 'scores', 'pred_classes', 'pred_masks'])
                    pred_masks = pred_inst.pred_masks  # (num_inst, 1, 28, 28)
                    scores = pred_inst.scores  # (num_inst, )
                    # sigmoid already applied
                    binary_masks = pred_masks > self.maskness_thresh
                    seg_scores = (pred_masks * binary_masks.float()).sum((1, 2, 3)) / binary_masks.sum((1, 2, 3))
                    seg_scores[binary_masks.sum((1, 2, 3)) == 0] = 0  # avoid nan
                    updated_scores = scores * seg_scores
                    pred_inst.set('scores', updated_scores)
                    # update order
                    scores, indices = updated_scores.sort(descending=True)
                    pred_inst = pred_inst[indices]
                    assert (pred_inst.scores == scores).all()

            # todo: add args to keep topk=100 instances for each image
            # pred_instances = [pred[:100] for pred in pred_instances]
            return pred_instances, {}

    def _forward_box(self, features, proposals, targets=None, keep_all_before_merge=False):
        """
        Args:
            features, targets: the same as in
                Same as in :meth:`ROIHeads.forward`.
            proposals (list[Instances]): the per-image object proposals with
                their matching ground truth.
                Each has fields "proposal_boxes", and "objectness_logits",
                "gt_classes", "gt_boxes".
        """
        features = [features[f] for f in self.box_in_features]
        if not self.training and int(getattr(self, "fixed_num_proposals", 0)) > 0:
            proposals = self._normalize_inference_proposals(proposals)
        head_outputs = []  # (predictor, predictions, proposals)
        prev_pred_boxes = None
        image_sizes = [x.image_size for x in proposals]
        final_box_features = None
        final_box_pooler_features = None
        final_box_pooler_features_expanded = None
        optimize_single_class_inference = (
            (not self.training)
            and self.num_classes == 1
            and not any(getattr(p, "use_sigmoid_ce", False) for p in self.box_predictor)
            and os.environ.get("EVA_CASCADE_SINGLE_CLASS_STREAMING_SCORES", "0") == "1"
        )
        avg_fg_scores_per_image = None
        final_predictor = None
        final_predictions = None
        final_proposals = None
        for k in range(self.num_cascade_stages):
            if k > 0:
                # The output boxes of the previous stage are used to create the input
                # proposals of the next stage.
                proposals = self._create_proposals_from_boxes(
                    prev_pred_boxes,
                    image_sizes,
                    prev_proposals=proposals,
                )
                if self.training:
                    proposals = self._match_and_label_boxes(proposals, k, targets)
            need_final_features = (
                (not self.training)
                and (
                    self.return_box_features
                    or self.return_box_pooler_features
                    or self.return_box_pooler_features_expanded
                )
                and (k == self.num_cascade_stages - 1)
            )
            if need_final_features:
                (
                    predictions,
                    final_box_features,
                    final_box_pooler_features,
                    final_box_pooler_features_expanded,
                ) = self._run_stage(
                    features,
                    proposals,
                    k,
                    return_box_features=self.return_box_features,
                    return_box_pooler_features=self.return_box_pooler_features,
                    return_box_pooler_features_expanded=self.return_box_pooler_features_expanded,
                )
            else:
                predictions = self._run_stage(features, proposals, k)
            prev_pred_boxes = self.box_predictor[k].predict_boxes(predictions, proposals)
            if optimize_single_class_inference:
                pred_class_logits, _ = predictions
                fg_probs = torch.sigmoid(
                    pred_class_logits[:, 0] - pred_class_logits[:, 1]
                ).unsqueeze(1)
                num_prop_per_image = [len(p) for p in proposals]
                fg_probs_per_image = fg_probs.split(num_prop_per_image, dim=0)
                if avg_fg_scores_per_image is None:
                    avg_fg_scores_per_image = [x.clone() for x in fg_probs_per_image]
                else:
                    for i, fg_scores in enumerate(fg_probs_per_image):
                        avg_fg_scores_per_image[i].add_(fg_scores)
                final_predictor = self.box_predictor[k]
                final_predictions = predictions
                final_proposals = proposals
            else:
                head_outputs.append((self.box_predictor[k], predictions, proposals))

        if self.training:
            losses = {}
            storage = get_event_storage()
            for stage, (predictor, predictions, proposals) in enumerate(head_outputs):
                with storage.name_scope("stage{}".format(stage)):
                    stage_losses = predictor.losses(predictions, proposals)
                losses.update({k + "_stage{}".format(stage): v for k, v in stage_losses.items()})
            return losses
        else:
            if optimize_single_class_inference:
                assert avg_fg_scores_per_image is not None
                scores = [
                    torch.cat(
                        (
                            fg_scores * (1.0 / self.num_cascade_stages),
                            1.0 - fg_scores * (1.0 / self.num_cascade_stages),
                        ),
                        dim=1,
                    )
                    for fg_scores in avg_fg_scores_per_image
                ]
                predictor, predictions, proposals = (
                    final_predictor,
                    final_predictions,
                    final_proposals,
                )
            else:
                # Each is a list[Tensor] of length #image. Each tensor is Ri x (K+1)
                scores_per_stage = [h[0].predict_probs(h[1], h[2]) for h in head_outputs]

                # Average the scores across heads
                scores = [
                    sum(list(scores_per_image)) * (1.0 / self.num_cascade_stages)
                    for scores_per_image in zip(*scores_per_stage)
                ]
                # Use the boxes/logits of the last head
                predictor, predictions, proposals = head_outputs[-1]
            pred_class_logits, _ = predictions
            num_prop_per_image = [len(p) for p in proposals]
            logits_per_image = pred_class_logits.split(num_prop_per_image, dim=0)
            box_features_per_image = None
            if self.return_box_features and final_box_features is not None:
                box_features_per_image = final_box_features.split(num_prop_per_image, dim=0)
            box_pooler_features_per_image = None
            if self.return_box_pooler_features and final_box_pooler_features is not None:
                box_pooler_features_per_image = final_box_pooler_features.split(
                    num_prop_per_image, dim=0
                )
            box_pooler_features_expanded_per_image = None
            if (
                self.return_box_pooler_features_expanded
                and final_box_pooler_features_expanded is not None
            ):
                box_pooler_features_expanded_per_image = final_box_pooler_features_expanded.split(
                    num_prop_per_image, dim=0
                )
            boxes = predictor.predict_boxes(predictions, proposals)
            filtered_scores = []
            filtered_logits = []
            filtered_boxes = []
            filtered_box_features = [] if box_features_per_image is not None else None
            filtered_box_pooler_features = (
                [] if box_pooler_features_per_image is not None else None
            )
            filtered_box_pooler_features_expanded = (
                [] if box_pooler_features_expanded_per_image is not None else None
            )
            for i, proposal in enumerate(proposals):
                valid_count = len(proposal)
                if proposal.has("proposal_valid_mask"):
                    valid_count = int(proposal.proposal_valid_mask.to(torch.int32).sum().item())
                filtered_scores.append(scores[i][:valid_count])
                filtered_logits.append(logits_per_image[i][:valid_count])
                filtered_boxes.append(boxes[i][:valid_count])
                if filtered_box_features is not None:
                    filtered_box_features.append(box_features_per_image[i][:valid_count])
                if filtered_box_pooler_features is not None:
                    filtered_box_pooler_features.append(box_pooler_features_per_image[i][:valid_count])
                if filtered_box_pooler_features_expanded is not None:
                    filtered_box_pooler_features_expanded.append(
                        box_pooler_features_expanded_per_image[i][:valid_count]
                    )
            pred_instances, kept_indices = fast_rcnn_inference(
                filtered_boxes,
                filtered_scores,
                image_sizes,
                predictor.test_score_thresh,
                predictor.test_nms_thresh,
                predictor.test_topk_per_image,
                use_soft_nms=self.use_soft_nms,
                method=self.method,
                iou_threshold=self.iou_threshold,
                sigma=self.sigma,
                class_wise=self.class_wise,  # for soft-nms
                override_score_thresh=self.override_score_thresh,
                keep_all_before_merge=keep_all_before_merge,
            )
            # Attach per-instance class logits (K+1) for downstream use (e.g., JSONL export)
            if pred_instances and filtered_logits:
                for i, (inst, logits, kept) in enumerate(zip(pred_instances, filtered_logits, kept_indices)):
                    if len(inst) == 0:
                        inst.set("pred_class_logits", logits[:0])
                        if filtered_box_features is not None:
                            inst.set("pred_box_features", filtered_box_features[i][:0])
                        if filtered_box_pooler_features is not None:
                            inst.set(
                                "pred_box_pooler_features",
                                filtered_box_pooler_features[i][:0],
                            )
                        if filtered_box_pooler_features_expanded is not None:
                            inst.set(
                                "pred_box_pooler_features_expanded",
                                filtered_box_pooler_features_expanded[i][:0],
                            )
                        continue
                    inst.set("pred_class_logits", logits[kept])
                    if filtered_box_features is not None:
                        inst.set("pred_box_features", filtered_box_features[i][kept])
                    if filtered_box_pooler_features is not None:
                        inst.set("pred_box_pooler_features", filtered_box_pooler_features[i][kept])
                    if filtered_box_pooler_features_expanded is not None:
                        inst.set(
                            "pred_box_pooler_features_expanded",
                            filtered_box_pooler_features_expanded[i][kept],
                        )
            return pred_instances

    def _normalize_inference_proposals(self, proposals):
        target = int(getattr(self, "fixed_num_proposals", 0))
        if target <= 0:
            return proposals

        normalized = []
        for proposal in proposals:
            boxes = proposal.proposal_boxes.tensor
            num_boxes = int(boxes.shape[0])
            num_valid = min(num_boxes, target)
            valid_mask = torch.zeros((target,), dtype=torch.bool, device=boxes.device)
            valid_mask[:num_valid] = True

            if num_boxes >= target:
                padded_boxes = boxes[:target]
            else:
                if num_boxes > 0:
                    pad_box = boxes[:1].expand(target - num_boxes, -1)
                else:
                    h, w = proposal.image_size
                    pad_box = boxes.new_tensor(
                        [[0.0, 0.0, max(float(w - 1), 1.0), max(float(h - 1), 1.0)]]
                    ).expand(target, -1)
                padded_boxes = torch.cat([boxes, pad_box[: target - num_boxes]], dim=0)

            prop = Instances(proposal.image_size)
            prop.proposal_boxes = Boxes(padded_boxes)
            prop.proposal_valid_mask = valid_mask
            normalized.append(prop)
        return normalized

    @torch.no_grad()
    def _match_and_label_boxes(self, proposals, stage, targets):
        """
        Match proposals with groundtruth using the matcher at the given stage.
        Label the proposals as foreground or background based on the match.

        Args:
            proposals (list[Instances]): One Instances for each image, with
                the field "proposal_boxes".
            stage (int): the current stage
            targets (list[Instances]): the ground truth instances

        Returns:
            list[Instances]: the same proposals, but with fields "gt_classes" and "gt_boxes"
        """
        num_fg_samples, num_bg_samples = [], []
        for proposals_per_image, targets_per_image in zip(proposals, targets):
            match_quality_matrix = pairwise_iou(
                targets_per_image.gt_boxes, proposals_per_image.proposal_boxes
            )
            # proposal_labels are 0 or 1
            matched_idxs, proposal_labels = self.proposal_matchers[stage](match_quality_matrix)
            if len(targets_per_image) > 0:
                gt_classes = targets_per_image.gt_classes[matched_idxs]
                # Label unmatched proposals (0 label from matcher) as background (label=num_classes)
                gt_classes[proposal_labels == 0] = self.num_classes
                gt_boxes = targets_per_image.gt_boxes[matched_idxs]
            else:
                gt_classes = torch.zeros_like(matched_idxs) + self.num_classes
                gt_boxes = Boxes(
                    targets_per_image.gt_boxes.tensor.new_zeros((len(proposals_per_image), 4))
                )
            proposals_per_image.gt_classes = gt_classes
            proposals_per_image.gt_boxes = gt_boxes

            num_fg_samples.append((proposal_labels == 1).sum().item())
            num_bg_samples.append(proposal_labels.numel() - num_fg_samples[-1])

        # Log the number of fg/bg samples in each stage
        storage = get_event_storage()
        storage.put_scalar(
            "stage{}/roi_head/num_fg_samples".format(stage),
            sum(num_fg_samples) / len(num_fg_samples),
        )
        storage.put_scalar(
            "stage{}/roi_head/num_bg_samples".format(stage),
            sum(num_bg_samples) / len(num_bg_samples),
        )
        return proposals

    def _run_stage(
        self,
        features,
        proposals,
        stage,
        return_box_features=False,
        return_box_pooler_features=False,
        return_box_pooler_features_expanded=False,
    ):
        """
        Args:
            features (list[Tensor]): #lvl input features to ROIHeads
            proposals (list[Instances]): #image Instances, with the field "proposal_boxes"
            stage (int): the current stage

        Returns:
            Same output as `FastRCNNOutputLayers.forward()`.
        """
        box_pooler_features = self.box_pooler(features, [x.proposal_boxes for x in proposals])
        box_features = box_pooler_features
        # The original implementation averages the losses among heads,
        # but scale up the parameter gradients of the heads.
        # This is equivalent to adding the losses among heads,
        # but scale down the gradients on features.
        if self.training:
            box_features = _ScaleGradient.apply(box_features, 1.0 / self.num_cascade_stages)
        box_features = self.box_head[stage](box_features)
        predictions = self.box_predictor[stage](box_features)
        if return_box_features or return_box_pooler_features or return_box_pooler_features_expanded:
            out_pooler_features_expanded = None
            if return_box_pooler_features_expanded:
                expanded_boxes = self._expanded_proposal_boxes_for_pooler(
                    proposals=proposals,
                    scale=float(self.box_pooler_expanded_scale),
                )
                out_pooler_features_expanded = self.box_pooler(features, expanded_boxes)
            out_box_features = box_features if return_box_features else None
            out_pooler_features = box_pooler_features if return_box_pooler_features else None
            return predictions, out_box_features, out_pooler_features, out_pooler_features_expanded
        return predictions

    @staticmethod
    def _expanded_proposal_boxes_for_pooler(proposals, scale: float):
        scale = float(scale)
        if scale <= 0:
            raise ValueError(f"box_pooler_expanded_scale must be >0, got {scale}")
        out = []
        for p in proposals:
            boxes = p.proposal_boxes.tensor
            if boxes.numel() == 0:
                out.append(Boxes(boxes))
                continue
            x1 = boxes[:, 0]
            y1 = boxes[:, 1]
            x2 = boxes[:, 2]
            y2 = boxes[:, 3]
            cx = 0.5 * (x1 + x2)
            cy = 0.5 * (y1 + y2)
            w = (x2 - x1) * scale
            h = (y2 - y1) * scale
            expanded = torch.stack(
                [
                    cx - 0.5 * w,
                    cy - 0.5 * h,
                    cx + 0.5 * w,
                    cy + 0.5 * h,
                ],
                dim=1,
            )
            b = Boxes(expanded)
            b.clip(p.image_size)
            out.append(b)
        return out

    def _forward_mask(self, features, instances):
        """Forward mask branch and optionally attach mask-pooler intermediate features."""
        if not self.mask_on:
            return {} if self.training else instances

        # Keep training path identical to StandardROIHeads.
        if self.training:
            return super()._forward_mask(features, instances)

        if self.mask_pooler is not None:
            mask_in_features = [features[f] for f in self.mask_in_features]
            boxes = [x.pred_boxes for x in instances]
            mask_pooler_features = self.mask_pooler(mask_in_features, boxes)
        else:
            # Rare path: mask head directly consumes feature dict.
            return super()._forward_mask(features, instances)

        out_instances = self.mask_head(mask_pooler_features, instances)

        if self.return_mask_pooler_features:
            num_inst_per_image = [len(x) for x in out_instances]
            per_image = mask_pooler_features.split(num_inst_per_image, dim=0)
            for inst, feat in zip(out_instances, per_image):
                inst.set("pred_mask_pooler_features", feat)
        return out_instances

    def _create_proposals_from_boxes(self, boxes, image_sizes, prev_proposals=None):
        """
        Args:
            boxes (list[Tensor]): per-image predicted boxes, each of shape Ri x 4
            image_sizes (list[tuple]): list of image shapes in (h, w)

        Returns:
            list[Instances]: per-image proposals with the given boxes.
        """
        # Just like RPN, the proposals should not have gradients
        boxes = [Boxes(b.detach()) for b in boxes]
        proposals = []
        prev_proposals = prev_proposals or [None] * len(boxes)
        for boxes_per_image, image_size, prev_proposal in zip(boxes, image_sizes, prev_proposals):
            boxes_per_image.clip(image_size)
            if self.training:
                # do not filter empty boxes at inference time,
                # because the scores from each stage need to be aligned and added later
                boxes_per_image = boxes_per_image[boxes_per_image.nonempty()]
            prop = Instances(image_size)
            prop.proposal_boxes = boxes_per_image
            if prev_proposal is not None and prev_proposal.has("proposal_valid_mask"):
                prop.proposal_valid_mask = prev_proposal.proposal_valid_mask
            proposals.append(prop)
        return proposals
