# Copyright (c) Facebook, Inc. and its affiliates.

import os
from pathlib import Path


_native_extension_dir = os.environ.get("EVA02_NATIVE_EXTENSION_DIR")
if _native_extension_dir:
    _native_path = Path(_native_extension_dir).expanduser().resolve()
    if _native_path.is_dir() and str(_native_path) not in __path__:
        __path__.append(str(_native_path))

from .utils.env import setup_environment

setup_environment()


# This line will be programatically read/write by setup.py.
# Leave them at the bottom of this file and don't touch them.
__version__ = "0.6"
